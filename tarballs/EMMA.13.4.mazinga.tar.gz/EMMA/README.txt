********************************************************************************
EMMA - Empathy Motions along fluctuation MAtrix
release 13.4.mazinga

Copyright (c) 2011-2013, National Research Council, CNR-ICRM, MILANO
Dario Corrada, Giorgio Colombo.

This work is licensed under a Creative Commons
Attribution-NonCommercial-ShareAlike 3.0 Unported License.
********************************************************************************

*** SOFTWARE REQUIREMENTS ***
- GROMACS v4.5.4
- GnuPlot 4.4.4
- R v2.10.0
    with package dependencies: cluster; RColorBrewer; RankAggreg.
    
EMMA has been tested tu run also with GROMACS v4.0.7, no tests have been on 
subsequent R versions.
In order to define specific paths please edit <EMMA.reloaded.pl> at 
"BIN n' CONFS" section.


*** ENVIRONMENTS SETTINGS ***
Edit your local [.bashrc] file as follows amd source it:
    
    export PATH=/home/user/opt:/home/user/opt/RAGE/bin:/home/user/opt/EMMA/bin:$PATH

</home/user/opt> is the parent dir in which EMMA and RAGE are installed.

*** INPUT FILES (with exact filenames) ***
- topol.tpr
- traj.xtc
- rmsd.xpm
- cluster.log

The output results are strongly influenced by how the trajectory file is 
generated. In order to obtain optimal results it is suggested to prepare an xtc 
file without periodic boundary conditions artifacts only composed of the 
equilibrated part of simulation.

The input files <rmsd.xpm> or <cluster.log> are required only for those cases 
in which sampling rely on cluster analysis pre-processing step.