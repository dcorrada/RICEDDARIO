********************************************************************************
ISABEL - ISabel is Another BEppe Layer
release 13.4.mazinga

Copyright (c) 2011-2013, National Research Council, CNR-ICRM, MILANO
Dario Corrada, Giorgio Colombo.

This work is licensed under a Creative Commons
Attribution-NonCommercial-ShareAlike 3.0 Unported License.
********************************************************************************

*** SOFTWARE REQUIREMENTS ***
- AMBER 9
- GnuPlot 4.4.4

ISABEL has been tested tu run also with AMBER 11 but it is not the default 
setting; please edit <ISABEL.pl> at "PATHS" section as well


*** ENVIRONMENTS SETTINGS ***
Edit your local [.bashrc] file as follows amd source it:
    
    export PATH=/home/user/opt:/home/user/opt/ISABEL/bin:$PATH

</home/user/opt> is the parent dir in which ISABEL are installed.

