#!/bin/sh

echo "child goes to sleep..."
sleep 360
echo "child awake"
