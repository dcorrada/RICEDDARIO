#!/bin/sh

cd /home/dario/tmp/KILL
echo "singing a lullaby for my child"
./child.sh &
echo "parent goes to sleep..."
sleep 1000
echo "parent awake"