.onLoad <- function(lib,pkg) require(methods)
