`overall.test` <-
function (gene.vec = NA, trans.vec = NA, xref = NA, go2term = NA, gene2path = NA) {
# Questa funzione lancia il test statistico implementato nel package CORNA (funzione <corna.test.fun>) su: 1) KEGG pathway; 2) GO molecular function; 3) GO biological process; 4) GO cellular component. Ritorna una lista di 4 dataframe, ognuno secondo il formato presentato da <corna.test.fun> (v. documentazione allegata alla funzione).
# <gene.vec>    OBBLIGATORIO, dataframe di ID universo/popolazione in formato Ensembl Gene (usare funzione <ensembl.unipop>)
# <trans.vec>   OBBLIGATORIO, dataframe di ID universo/popolazione in formato Ensembl Transcript (usare funzione <ensembl.unipop>)
# <xref>        dataset di crosslink di BioMart, se non viene definito carica il dataset predefinito del package (<biomart.crosslinks>); altrimenti caricare un dataset ex-novo con la funzione <fetch.crosslinks>
# <go2term>     dataset di associazioni GO, se non viene definito carica il dataset predefinito del package (<corna.go2term>); altrimenti caricare un dataset ex-novo con la funzione <GO2df.fun> del package CORNA
# <gene2path>   dataset di associazioni KEGG, se non viene definito carica il dataset predefinito del package (<corna.gene2path.mmu>); altrimenti caricare un dataset ex-novo con la funzione <KEGG2df.fun> del package CORNA
    
#     INIZIALIZZAZIONI
    if (is.na(gene.vec) || is.na(trans.vec)) { stop("undef parameters: <gene.vec> and/or <trans.vec>"); }
    if (is.na(xref)) { data(biomart.crosslinks);xref <- biomart.crosslinks; }
    if (is.na(go2term)) { data(corna.go2term);go2term <- corna.go2term; }
    if (is.na(gene2path)) { data(corna.gene2path.mmu);gene2path <- corna.gene2path.mmu; }
    
    writeLines("\n-- Creating overrepresentation dataset...");
    writeLines("\t Testing KEGG pathway...");
    path2name <- unique(gene2path[c("path", "name")]);
    test.KEGG <- corna.test.fun(x = gene.vec$population, y = gene.vec$universe, z = gene2path,
                                hypergeometric = TRUE, fisher = TRUE,
                                hyper.lower.tail = FALSE, fisher.alternative = "two.sided", p.adjust.method = "none",
                                min.pop = 10, desc = path2name );
    
    writeLines("\t Testing GO molecular function...");
    test.GOmf <- corna.test.fun(x = trans.vec$population, y = trans.vec$universe, z = xref$tran2gomf,
                                hypergeometric = TRUE, fisher = TRUE,
                                hyper.lower.tail = FALSE, fisher.alternative = "two.sided", p.adjust.method = "none",
                                min.pop = 10, desc = go2term );
    
    writeLines("\t Testing GO cellular component...");
    test.GOcc <- corna.test.fun(x = trans.vec$population, y = trans.vec$universe, z = xref$tran2gocc,
                                hypergeometric = TRUE, fisher = TRUE,
                                hyper.lower.tail = FALSE, fisher.alternative = "two.sided", p.adjust.method = "none",
                                min.pop = 10, desc = go2term );
    
    writeLines("\t Testing GO biological process...");
    test.GObp <- corna.test.fun(x = trans.vec$population, y = trans.vec$universe, z = xref$tran2gobp,
                                hypergeometric = TRUE, fisher = TRUE,
                                hyper.lower.tail = FALSE, fisher.alternative = "two.sided", p.adjust.method = "none",
                                min.pop = 10, desc = go2term );
    
    writeLines("\t Subsetting on p-value..."); # tengo solo i dati con p-value <= 0.05
    test.KEGG <- subset(test.KEGG, hypergeometric <= 0.05);
    test.GOmf <- subset(test.GOmf, hypergeometric <= 0.05);
    test.GOcc <- subset(test.GOcc, hypergeometric <= 0.05);
    test.GObp <- subset(test.GObp, hypergeometric <= 0.05);
    
    test.list <- list( KEGG = test.KEGG, GOmf = test.GOmf, GOcc = test.GOcc, GObp = test.GObp);
    writeLines("-- Overrepresentation dataset done!");
    return(test.list);
}