`query.build.universe` <-
function (mir = "all") {
# # questa funzione allestisce le query dei gruppi UNIVERSO
# <mir> stringa che definisce il miRNA da prendere in considerazione. Di default ("all") considera tutte le predizioni di tutti i miRNA

# # il template <my.query.select> è una lista in cui ogni componente rappresenta una parte di un query SQL "select" completa
    my.query.select <- list ( select = c("SELECT"), from = c("FROM"), where = c("WHERE"), join = c("JOIN", "ON"), order = c("ORDER BY"), group = c("GROUP BY"), having = c("HAVING"), limit = c("LIMIT") );
    
# # TUTTE le UTR del dataset
    if (mir=='all') {
#         creo una lista contenente solo gli elementi del template <my.query.select> che mi servono
        query.universe <- c(my.query.select["select"],
                            my.query.select["from"],
                            my.query.select["join"]);
        
#         riempio i singoli componenti di <query.universe> con gli attributi mancanti
        attach(query.universe);
        query.universe$select <- c(select, 'DISTINCT a.RefSeqID, b.mRNA AS \'mm9\', a.GeneID, a.GeneSymbol');
        query.universe$from <- c(from, 'fasta3utr AS a');
        query.universe$join <- c('LEFT', join[1], 'kgXref AS b', join[2], 'a.RefSeqID = b.mRNA');
        detach(query.universe);
        
        
# # TUTTE le UTR predette per ogni miRNA
    } else {
            query.universe <- c(my.query.select["select"],
                                my.query.select["from"],
                                my.query.select["join"],
                                my.query.select["join"],
                                my.query.select["where"]);
            names(query.universe) <- c(names(query.universe)[1:2], "join.1",  "join.2", names(query.universe)[5]);
        
            attach(query.universe);
            query.universe$select <- c(select, 'DISTINCT b.RefSeqID, c.mRNA AS \'mm9\', b.GeneID, b.GeneSymbol');
            query.universe$from <- c(from, 'prediction_summary AS a');
            query.universe$join.1 <- c(join.1[1], 'fasta3utr AS b', join.1[2], 'a.refseqID = b.RefSeqID');
            query.universe$join.2 <- c('LEFT', join.2[1], 'kgXref AS c', join.2[2], 'a.RefSeqID = c.mRNA');
            query.universe$where <- c(where, paste('(a.mirID LIKE \'', mir, '\')', sep=""));
            detach(query.universe);
    }
    
    return(query.universe);
}

