`term2target` <-
function (population = NA, term.list = NA, term.type = "GOmf", xref = list()) {
# Questa funzione restituisce un dataframe contenente informazioni su tutti i geni target che sono accomunati sotto uno stesso termine (GO o KEGG)
# <population>      OBBLIGATORIO, unipop dataset ottenuto con la funzione <fetch.unipop>
# <term.list>       OBBLIGATORIO, stringa o vettore che definisce l'elenco degli identificatori
# <term.type>       stringa che identifica il tipo di identificatore (GO o KEGG), le modalità di <term.type> saranno "GObp", "GOcc", "GOmf" e "KEGG"
# <xref>            lista di cross-references, i cui componenti di default sono i dataset <biomart.crosslinks>, <corna.go2term> e <corna.gene2path.mmu>



    if (is.na(population) || is.na(term.list)) { stop("undef parameters: <population> and/or <term.list>"); }
    
#     INIZIALIZZAZIONI
    data(biomart.crosslinks); # cross references on BioMart
    data(corna.go2term); # get links between GO id and term
    data(corna.gene2path.mmu); # read pathway information from KEGG for mmu
    xref <- list(biomart = biomart.crosslinks, go2term = corna.go2term, kegg2term = corna.gene2path.mmu); # faccio un listone unico dei dataset caricati qua sopra
    term.list <- as.data.frame(term.list, stringsAsFactors=FALSE); names(term.list) <- c("termID");
    ensembl2refseq <- data.frame(); # collega l'ID di Ensembl (transcript o gene) ad un ID RefSeq
    ensembl2term <- data.frame(); # collega l'ID di Ensembl (transcript o gene) ad un ID di GO o KEGG
    term2desc <- data.frame(); # collega gli ID di GO o KEGG alla loro descrizione
    
#     Nel seguente blocco di codice faccio un parsing della lista <xref> in modo da ottenere i dataframes <ensembl2refseq>, <ensembl2term> e <term2desc> con un formato uniforme, a prescindere che tratti EnsemblGene o EnsemTranscript, GObp oppure KEGG
    {
        if (term.type == "GObp") {
            writeLines("-- Performing search on GO Biological Process");
            ensembl2refseq <- xref$biomart$refseq2ensembl_tran;
            ensembl2term <- xref$biomart$tran2gobp;
            term2desc <- xref$go2term;
        } else if (term.type == "GOcc") {
            writeLines("-- Performing search on GO Cellular Component");
            ensembl2refseq <- xref$biomart$refseq2ensembl_tran;
            ensembl2term <- xref$biomart$tran2gocc;
            term2desc <- xref$go2term;xrexref$biomartf$biomart
        } else if (term.type == "GOmf") {
            writeLines("-- Performing search on GO Molecular Function");
            ensembl2refseq <- xref$biomart$refseq2ensembl_tran;
            ensembl2term <- xref$biomart$tran2gomf;
            term2desc <- xref$go2term;
        } else if (term.type == "KEGG") {
            writeLines("-- Performing search on KEGG Pathway");
            ensembl2refseq <- xref$biomart$refseq2ensembl_gene;
            ensembl2term <- xref$kegg2term;
            term2desc <- xref$kegg2term;
            ensembl2term$name <- NULL;
            term2desc$gene <- NULL;
            term2desc <- unique(term2desc);
        } else {
            stop("unknown <term.type> parameter");
        }
        names(ensembl2refseq) <- c("refseqID", "ensemblID");
        names(ensembl2term) <- c("ensemblID", "termID");
        names(term2desc) <- c("termID", "term.desc");
    }
    
#     ora ridefinisco xref; lo scopo è quello di ottenere un nuovo dataframe dove per ogni elemento di <term.list> ho un elenco completo dei codici RefSeq dei trascritti a cui appartengono
    {
#         in primo luogo unisco la lista degli identifier - dati in input con il vettore <term.list> - al dataframe <term2desc>
        fusione.A <- merge(x = term2desc, y = term.list, by = "termID", stringsAsFactors = FALSE);
        
#         ora fondo <fusione.A> con <ensembl2term> e <ensembl2refseq>
        fusione.B <- merge(x = ensembl2term, y = fusione.A, by = "termID");
        fusione.C <- merge(x = ensembl2refseq, y = fusione.B, by = "ensemblID");
        
        xref <- fusione.C;
    }
    
#     a questo punto prendo i trascritti presenti nella popolazione di riferimento <population> e vado a fare un matching con i dati appena elaborati per <xref>
    final.match <- data.frame();
    {
#         prima di tutto snellisco e ridefinisco <population> con solo i dati che mi interessano
        population <- subset(population$population.data, select = c("mm9", "GeneID", "GeneSymbol", "rank", "description"));
        names(population) <- c("refseqID", "geneID", "symbol", "rank", "gene.desc");
        
        final.match <- merge(x = population, y = xref, by = "refseqID");
    }
    
#     riordino i risultati prima di buttarli fuori
    final.match <- final.match[order(final.match$term.desc, final.match$rank, decreasing=TRUE), ];
    
#     RETURN VALUE
#     result <- list(ensembl2refseq = ensembl2refseq, ensembl2term = ensembl2term, term2desc = term2desc);
#     result <- xref;
#     result <- population;
    result <- final.match;
    return(result);
}