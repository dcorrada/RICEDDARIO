`db.update.tests` <-
function (results = NA, tablename = NA, db.usr = "dario", db.pw = "foo", db.host = "155.253.6.97", db.name = "mm9") {
# Questa funzione recupera la lista ottenuta con la funzione <overall.test> e li carica su una tabella apposita sul DB.
# <results>     OBBLIGATORIO, lista, dataset dei risultati ottenuti dopo aver usato la funzione <overall.test>
# <tablename>   OBBLIGATORIO, stringa, nome della tabella da caricare sul DB
# <db.usr>      stringa, connessione al DB, nome utente
# <db.pw>       stringa, connessione al DB, password
# <db.host>     stringa, connessione al DB, IP address (o "localhost")
# <db.name>     stringa, connessione al DB, nome del DB
    
    if (is.na(results) || is.na(tablename)) { stop("undef parameters: <results> and/or <tablename>"); }
    
    dbd<-dbDriver("MySQL");   # carico il driver per MySQL
    dbh<-dbConnect(dbd, user = db.usr, password = db.pw, host = db.host, dbname = db.name); # mi connetto al database
    writeLines("-- connected to DB...");print(dbh);
    
#     upload dei dati: il dataset ottenuto in input <results> verrà splittato nelle sue singole componenti (i dataframe "$KEGG", "$GObp", "$GOcc" e "$GOmf"). Ogni componente verrà caricato sul DB come una tabella a sè stante
    for (term in names(results)) {
        tab.name <- paste(tablename, term, sep = "_"); # nome della tabella
        tab.data <- results[[term]]; # contenuto della tabella
        sth <- dbSendQuery(dbh, paste("DROP TABLE IF EXISTS", tab.name, sep =" ")); # rimuovo eventuali tabelle pre-esistenti
        
        writeLines(c("-- uploading <", tab.name, "> table\n"), sep = "");
        dbWriteTable(dbh, tab.name, tab.data, row.names = "TRUE"); # carico la tabella
        sth <- dbSendQuery(dbh, paste("ALTER TABLE", tab.name, "ADD PRIMARY KEY ( `row_names` ( 30 ) )", sep =" "));# e la indicizzo
    }
    
#     mi disconnetto dal database
    if (dbDisconnect(dbh)) { writeLines("-- disconnected from DB");print(dbh);
    } else { writeLines("W- disconnection from DB failed!");print(dbh); }
}