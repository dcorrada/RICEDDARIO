`fetch.unipop` <-
function(uni.mir = "all", pop.mir = NA, pop.acc = FALSE, pop.orth = FALSE, pop.limit = 100, odbc.pw = NA, odbc.dsn = "mirna" ) {
# # questa funzione recupera universo e popolazione dal DB e li inserisce in due dataframe
#
# <odbc.dsn>    Data Source Name, configurare il file </etc/odbc.ini> prima di usare un dsn diverso da "mirna"
# <odbc.pw>     Password di accesso al database definito dal DSN
# 
# <uni.mir>     v. funzione <query.build.universe>
# 
# <pop.mir>     v. funzione <query.build.population>
# <pop.acc>     v. funzione <query.build.population>
# <pop.orth>    v. funzione <query.build.population>
# 
# <pop.limit>   numero di record che riempiono il dataframe che descrive la popolazione


    universotab <- paste("universotab", Sys.getpid(), sep="_");
    popolazionetab <- paste("popolazionetab", Sys.getpid(), sep="_");

    
    writeLines("\n-- Creating target dataset...");
    if (is.na(pop.mir)) { stop("undef miRNA in <pop.mir> parameter"); }
    if (is.na(odbc.pw)) { stop("undef password in <odbc.pw> parameter"); }
    
    writeLines("\tOpening a database handle...");
    
    dbh<-odbcConnect(dsn = odbc.dsn, pw = odbc.pw);    # apro un canale ('dbh') su un DSN MySQL: le configurazioni dei DSN, sono nel file /etc/odbc.ini
#     odbcGetInfo(dbh);dbh;  # info sul canale
    sqlQuery(dbh, "use mm9");   # definisco il DB da usare
    
    writeLines("\tUpload universe...");
#     costruisco la query per l'universo
    universe.query.struct <- query.build.universe (uni.mir);
    universe.query.string <- coalesce.query (universe.query.struct);
    
    universe.tab <- data.frame();
    if (uni.mir == "all") { # ATTENZIONE: x convenienza di tempo uso un dataset di genoma di topo già pronto, anche se la funzione <query.build.universe> funziona comunque passandogli come parametro "all"
        data(universe.mm9);
        universe.tab <- universe.mm9;
    } else {
        sqlCopy(dbh, universe.query.string, universotab, rownames=F, verbose=F); # creo sul DB una tabella temporanea dei risultati della query
        universe.tab <- sqlFetch(dbh, universotab, nullstring = NA, stringsAsFactors = F); # fetching della query 
        universe.tab$GeneID <- as.character(universe.tab$GeneID); # converto il campo "GeneID" in stringa
    }
    
    writeLines("\tUploading population...");
#     costruisco la query per la popolazione
    population.query.struct <- query.build.population (pop.mir, acc = pop.acc, orth = pop.orth);
    population.query.string <- coalesce.query (population.query.struct);
    
    sqlCopy(dbh, population.query.string, popolazionetab, rownames=F, verbose=F);
    population.tab <- sqlFetch(dbh, popolazionetab, nullstring = NA, stringsAsFactors = F, max = pop.limit);
    population.tab$GeneID <- as.character(population.tab$GeneID);
    
#     elimino le tabelle temporanee create sul DB
    if (uni.mir != "all") { sqlDrop(dbh, universotab); } # ATTENZIONE: uso un dataset, non ho creato nessuna tabella
    sqlDrop(dbh, popolazionetab);
    
    odbcClose(dbh);  # chiudo il canale
    
    enrichment.input <- list(   universe.query = universe.query.string, population.query = population.query.string,
                                universe.data = universe.tab, population.data = population.tab);
    writeLines("-- Target dataset done!");
    return(enrichment.input);
}

