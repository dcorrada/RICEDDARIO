`fetch.crosslinks` <-
function (biomart = "ensembl", dataset = "mmusculus_gene_ensembl") {
# # questa funzione si occupa di reperire i riferimenti incrociati tra RefSeqID, eNSEMBL IDs (transcript e gene), GO IDs (cellular component, molecular function e biological process)
# <biomart>       definisce il database di BioMart. Per un elenco completo usare la funzione <listMarts> del package <biomaRt>
# <dataset>       definisce il dataset da un database selezionato. Per un elenco completo lanciare uno script del genere:
#                     library(biomaRt); mart <- useMart('ensembl'); listDatasets(mart);
    
    writeLines("\n-- Creazione oggetto <crosslink.list>...");
    
    writeLines("\n\tCaricamento associazioni tra <refseq_dna> ID e <ensembl_transcript_id>...");
    refseq2ensembl_tran <-  BioMart2df.fun( biomart=biomart, dataset=dataset,
                                            col.old=c("refseq_dna", "ensembl_transcript_id"),
                                            col.new=c("refseq", "ensembl_transcript"));
    writeLines("\n\tCaricamento associazioni tra <refseq_dna> ID e <ensembl_gene_id>...");
    refseq2ensembl_gene <-  BioMart2df.fun( biomart=biomart, dataset=dataset,
                                            col.old=c("refseq_dna", "ensembl_gene_id"),
                                            col.new=c("refseq", "ensembl_gene"));
    writeLines("\n\tCaricamento associazioni tra <ensembl_transcript_id> ID e <go_biological_process_id>...");
    tran2gobp  <- BioMart2df.fun(   biomart=biomart, dataset=dataset,
                                    col.old=c("ensembl_transcript_id", "go_biological_process_id"),
                                    col.new=c("ensembl_transcript", "gobp"));
    writeLines("\n\tCaricamento associazioni tra <ensembl_transcript_id> ID e <go_cellular_component_id>...");
    tran2gocc  <- BioMart2df.fun(   biomart=biomart, dataset=dataset,
                                    col.old=c("ensembl_transcript_id", "go_cellular_component_id"),
                                    col.new=c("ensembl_transcript", "gocc"));
    writeLines("\n\tCaricamento associazioni tra <ensembl_transcript_id> ID e <go_molecular_function_id>...");
    tran2gomf  <- BioMart2df.fun(   biomart=biomart, dataset=dataset,
                                    col.old=c("ensembl_transcript_id", "go_molecular_function_id"),
                                    col.new=c("ensembl_transcript", "gomf"));
    
    crosslink.list <- list( BioMart.database = biomart, BioMart.dataset = dataset,
                            refseq2ensembl_tran = refseq2ensembl_tran, refseq2ensembl_gene = refseq2ensembl_gene,
                            tran2gobp = tran2gobp, tran2gocc = tran2gocc, tran2gomf = tran2gomf);
    
    writeLines("\n-- Creazione oggetto <crosslink.list> completata");
    return(crosslink.list);
}

