`ensembl.unipop` <-
function (type = "trans", xref = NA, unipop = NA) {
# Questa funzione estrae un dataframe di 2 componenti, entrambi vettori di stringhe contenenti gli Ensembl IDs rispettivamente di universo e popolazione
# <type>      definisce quale Ensembl ID estrarre: "trans" = Ensembl transcript, "gene" = Ensembl gene
# <xref>      dataframe di crosslinks nel formato del dataset "biomart.crosslinks"
# <unipop>    dataframe di target predetti nel formato del dataset "unipop.data"

    if (is.na(xref)) { 
        data(biomart.crosslinks);
        xref <- biomart.crosslinks;
    }
    
    if (is.na(unipop)) { 
        data(unipop.data);
        unipop <- unipop.data;
    }
    
    if (!(type %in%  c("trans", "gene"))) { stop("unknwon ensembl identifier");}
    
    uni.refseq.df <- unipop$universe.data; # df dei trascritti appartenenti all'universo
    pop.refseq.df <- unipop$population.data; # df dei trascritti appartenenti alla popolazione
    
    refseq2ensembl.df <- data.frame(); # df di associazione RefSeq Ensembl
    uni.ensembl.df <- data.frame();
    pop.ensembl.df <- data.frame();
    result <- list();
    
    if (type == "trans") {
        refseq2ensembl.df <- xref$refseq2ensembl_tran;
        
        uni.ensembl.df <- merge(x = uni.refseq.df, y = refseq2ensembl.df, by.x = "RefSeqID", by.y = "refseq", all = FALSE);
        uni.ensembl.df <- uni.ensembl.df[!is.na(uni.ensembl.df$ensembl_transcript),]; # rimuovo eventuali NA
        uni.ensembl.df <- uni.ensembl.df[!duplicated(uni.ensembl.df$ensembl_transcript),]; # rimuovo gli Ensembl transcript IDs ripetuti
        
        pop.ensembl.df <- merge(x = pop.refseq.df, y = refseq2ensembl.df, by.x = "RefSeqID", by.y = "refseq", all = FALSE);
        pop.ensembl.df <- pop.ensembl.df[!is.na(pop.ensembl.df$ensembl_transcript),];
        pop.ensembl.df <- pop.ensembl.df[!duplicated(pop.ensembl.df$ensembl_transcript),];

        result <- list( universe = uni.ensembl.df$ensembl_transcript, population = pop.ensembl.df$ensembl_transcript);
    }
    
    if (type == "gene") {
        refseq2ensembl.df <- xref$refseq2ensembl_gene; 
    
        uni.ensembl.df <- merge(x = uni.refseq.df, y = refseq2ensembl.df, by.x = "RefSeqID", by.y = "refseq", all = FALSE);
        uni.ensembl.df <- uni.ensembl.df[!is.na(uni.ensembl.df$ensembl_gene),]; # rimuovo eventuali NA
        uni.ensembl.df <- uni.ensembl.df[!duplicated(uni.ensembl.df$ensembl_gene),]; # rimuovo gli Ensembl transcript IDs ripetuti
        
        pop.ensembl.df <- merge(x = pop.refseq.df, y = refseq2ensembl.df, by.x = "RefSeqID", by.y = "refseq", all = FALSE);
        pop.ensembl.df <- pop.ensembl.df[!is.na(pop.ensembl.df$ensembl_gene),];
        pop.ensembl.df <- pop.ensembl.df[!duplicated(pop.ensembl.df$ensembl_gene),];
        
        result <- list( universe = uni.ensembl.df$ensembl_gene, population = pop.ensembl.df$ensembl_gene);
    }
    
    return(result);
}