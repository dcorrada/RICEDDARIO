`coalesce.query` <-
function (query.list = NA) {
# # questa funzione prende come input una lista del tipo <my.query.select> e ritorna una stringa unica in cui tutti i componenti sono uniti in un unica stringa

    if (is.na(query.list) || !is.list(query.list)) {
        stop("oggetto lista non definito: specificare una lista del tipo <my.query.select>");
    }
    
    query.elems <- unlist(query.list); # converto la lista in un vettore indicizzato
    
#     shifto il primo elemento di <query.elems> su <query.string>
    query.string <- query.elems[1];
    query.elems <- query.elems[-1];
    
    for (single.elem in query.elems) # accodo a <query.string> tutti gli elementi restanti
        query.string <- paste(query.string, single.elem);
    
    return(query.string);
}

